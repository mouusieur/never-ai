"""Observatory server package."""

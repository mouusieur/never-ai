"""Autonomously forged plugins."""

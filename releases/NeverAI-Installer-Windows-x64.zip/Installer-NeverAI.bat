@echo off
title NEVER-AI — Assistant d'Installation Windows
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -STA -File "%~dp0setup_wizard.ps1"
